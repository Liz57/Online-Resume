var newheaderName=HTMLheaderName.replace("%data%","Liz Maria James");
var newheaderRole=HTMLheaderRole.replace("%data%","Web Developer");
$("#header").prepend([newheaderRole]);
$("#header").prepend([newheaderName]);

var bio={
  "name":"Liz Maria James",
  "role":"Web Developer",
  "contacts":{
    "phone":"920009376",
    "twitter":"@lizjames",
    "email":"lizjames.57@gmail.com",
    "location":"India",
    "github":"Liz57"
  },
  "welcomeMessage": "All things will fall into the right place.Give time some time.",
  "skills":["creativity","reading","travelling"],
  "biopic":"images/fry.jpg"};
bio.display=function displayBio(){
  var welcomeMsg=HTMLwelcomeMsg.replace("%data%",bio.welcomeMessage);
  $("#header").append(welcomeMsg);
  var biopic=HTMLbioPic.replace("%data%",bio.biopic);
  $("#header").append(biopic);
  var github=HTMLgithub.replace("%data%",bio.contacts.github);
  $("#topContacts").append(github);
  var mobile=HTMLmobile.replace("%data%",bio.contacts.phone);
  $("#topContacts").append(mobile);
  var email=HTMLemail.replace("%data%",bio.contacts.email);
  $("#topContacts").append(email);
  var twitter=HTMLtwitter.replace("%data%",bio.contacts.twitter);
  $("#topContacts").append(twitter);
  var locations=HTMLlocation.replace("%data%",bio.contacts.location);
  $("#topContacts").append(locations);


  var newSkill;
  if(bio.skills.length>0){
    $("#header").append(HTMLskillsStart);
    newSkill=HTMLskills.replace("%data%",bio.skills[0]);
    $("#skills").append(newSkill);
    newSkill=HTMLskills.replace("%data%",bio.skills[1]);
    $("#skills").append(newSkill);
    newSkill=HTMLskills.replace("%data%",bio.skills[2]);
    $("#skills").append(newSkill);
  }
};
bio.display();


var projects={
  "activities":[{
    "title":"Offline Signature Verification",
    "dates":"April 2016 - March 2017",
    "description":"The concat method creates a new array consisting of the elements in the object on which it is called, followed in order by, for each argument, the elements of that argument (if the argument is an array) or the argument itself (if the argument is not an array). It does not recurse into nested array arguments.The concat method does not alter this or any of the arrays provided as arguments but instead returns a shallow copy that contains copies of the same elements combined from the original arrays. Elements of the original arrays are copied into the new array.",
    "image1":"images/197x148.gif",
    "image2":"images/197x148.gif"},
    {"title":"Hump Alert System",
    "dates":"December 2015 - March 2016",
    "description":"The concat method creates a new array consisting of the elements in the object on which it is called, followed in order by, for each argument, the elements of that argument (if the argument is an array) or the argument itself (if the argument is not an array). It does not recurse into nested array arguments.The concat method does not alter this or any of the arrays provided as arguments but instead returns a shallow copy that contains copies of the same elements combined from the original arrays. Elements of the original arrays are copied into the new array.",
    "image1":"images/197x148.gif",
    "image2":"images/197x148.gif"}]

};
projects.display=function displayProject(p_object){
  for(var activity in p_object.activities){
    $("#projects").append(HTMLprojectStart);
    var pTitle=HTMLprojectTitle.replace("%data%",p_object.activities[activity].title);
    $(".project-entry:last").append(pTitle);
    var pDates=HTMLprojectDates.replace("%data%",p_object.activities[activity].dates);
    $(".project-entry:last").append(pDates);
    var pDescription=HTMLprojectDescription.replace("%data%",p_object.activities[activity].description);
    $(".project-entry:last").append(pDescription);
    var pImage1=HTMLprojectImage.replace("%data%",p_object.activities[activity].image1);
    $(".project-entry:last").append(pImage1);
    var pImage2=HTMLprojectImage.replace("%data%",p_object.activities[activity].image2);
    $(".project-entry:last").append(pImage2);
  }
};
projects.display(projects);
var education={
"schools":[{
           "name": "VJCET College",
           "location": "Cochin",
           "degree": "Bachelors in Technology",
           "majors": "Electronics and Communication",
           "dates": "July 2013-May 2017"},
          {"name": "SHPS School",
          "location": "Kerala",
          "degree": "Certifcate exam",
          "dates": "August 2011-May 2013"}],
"onlineCourses":[{
            "title": "frontend-nanodegree",
            "school": "Udacity",
            "dates": " July 2017 -December 2017",
            "url":"https://www.udacity.com"},
           {"title": "Introduction to Cryptology",
             "school": "NPTEL,India",
             "dates": " June 2015 -Novemeber 2015",
             "url":"https://onlinecourses.nptel.ac.in"}]
           };
education.display=function displayeducationSchools(e_object){
  for(var school in e_object.schools){
    $("#education").append(HTMLschoolStart);
    var schoolName=HTMLschoolName.replace("%data%",e_object.schools[school].name);
    $(".education-entry:last").append(schoolName);
    var schoolDegree=HTMLschoolDegree.replace("%data%",e_object.schools[school].degree);
    $(".education-entry:last").append(schoolDegree);
    var schoolDates=HTMLschoolDates.replace("%data%",e_object.schools[school].dates);
    $(".education-entry:last").append(schoolDates);
    var schoolLocation=HTMLschoolLocation.replace("%data%",e_object.schools[school].location);
    $(".education-entry:last").append(schoolLocation);
    var schoolMajor=HTMLschoolMajor.replace("%data%",e_object.schools[school].majors);
    $(".education-entry:last").append(schoolMajor);
  }


  for(var oCourses in e_object.onlineCourses){
    $(".education-entry:last").append(HTMLonlineClasses);
    var onlineTitle=HTMLonlineTitle.replace("%data%",e_object.onlineCourses[oCourses].title);
    $(".education-entry:last").append(onlineTitle);
    var onlineSchool=HTMLonlineSchool.replace("%data%",e_object.onlineCourses[oCourses].school);
    $(".education-entry:last").append(onlineSchool);
    var onlineDates=HTMLonlineDates.replace("%data%",e_object.onlineCourses[oCourses].dates);
    $(".date-text:last").append(onlineDates);
    var onlineURL=HTMLonlineURL.replace("%data%",e_object.onlineCourses[oCourses].url);
    $(".education-entry:last").append(onlineURL);

  }
};
education.display(education);


var work={
  "jobs":[{
    title:"Web Developer",
    employer:"Freelancer",
    time:"July 2017- Future",
    description:"The concat method creates a new array consisting of the elements in the object on which it is called, followed in order by, for each argument, the elements of that argument (if the argument is an array) or the argument itself (if the argument is not an array). It does not recurse into nested array arguments.The concat method does not alter this or any of the arrays provided as arguments but instead returns a shallow copy that contains copies of the same elements combined from the original arrays. Elements of the original arrays are copied into the new array.",
    location: "Kerala"},
  {title:"Graphic Designer",
  employer:"JY Group",
  time:"January 2013 - December 2018",
  description:"The concat method creates a new array consisting of the elements in the object on which it is called, followed in order by, for each argument, the elements of that argument (if the argument is an array) or the argument itself (if the argument is not an array). It does not recurse into nested array arguments.The concat method does not alter this or any of the arrays provided as arguments but instead returns a shallow copy that contains copies of the same elements combined from the original arrays. Elements of the original arrays are copied into the new array.",
  location: "Kerala"},
  {title:"Photographer",
  employer:"Freelancer",
  time:"April 2012- Future",
  description:"The concat method creates a new array consisting of the elements in the object on which it is called, followed in order by, for each argument, the elements of that argument (if the argument is an array) or the argument itself (if the argument is not an array). It does not recurse into nested array arguments.The concat method does not alter this or any of the arrays provided as arguments but instead returns a shallow copy that contains copies of the same elements combined from the original arrays. Elements of the original arrays are copied into the new array.",
  location: "Kerala"}]};
work.display=function jobsdisplay(work){
  for(var job in work.jobs){
    $("#workExperience").append(HTMLworkStart);
    var employer=HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
    var title=HTMLworkTitle.replace("%data%",work.jobs[job].title);
    var employertitle=employer+title;
    $(".work-entry:last").append(employertitle);
    var dates=HTMLworkDates.replace("%data%",work.jobs[job].time);
    $(".work-entry:last").append(dates);
    var jobDescription=HTMLworkDescription.replace("%data%",work.jobs[job].description);
    $(".work-entry:last").append(jobDescription);
  }

};
work.display(work);

/*$("#document").click(function(loc){
  var x=loc.pageX;
  var y=loc.pageY;
  logClick(X,Y);
});*/

$("#mapDiv").append(googleMap);


  bio.displayf=function displayBio(){
    var github=HTMLgithub.replace("%data%",bio.contacts.github);
    $("#footerContacts").append(github);
    var mobile=HTMLmobile.replace("%data%",bio.contacts.phone);
    $("#footerContacts").append(mobile);
    var email=HTMLemail.replace("%data%",bio.contacts.email);
    $("#footerContacts").append(email);
    var twitter=HTMLtwitter.replace("%data%",bio.contacts.twitter);
    $("#footerContacts").append(twitter);
    var locations=HTMLlocation.replace("%data%",bio.contacts.location);
    $("#footerContacts").append(locations);
  };
  bio.displayf();
